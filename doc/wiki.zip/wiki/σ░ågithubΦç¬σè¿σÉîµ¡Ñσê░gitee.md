https://www.geekschool.org/2021/01/08/47483.html
注意有些下载下来的配置文件默认是同步master分支的，而本仓库主分支是main