0. 学习markdown 见[[markdown-0秒入门点击就会]]
1. git clone
2. （可选）导入进github desktop
    * 由于github desktop多年未修的bug，无法直接将wiki用链接导入github desktop.
3. 配置本地编辑器<br>
    1. 安装vscode插件从而支持gfm的 checkbox \[[]]等
        * markdown notes 支持各种链接
        * github markdown preview
        * 也可以试试最流行的markdown all in one 功能更丰富，就是不知道会不会和第二个冲突
        * 也可以直接试试foam，或许直接和github wiki完美协作了？
    2. 开启预览
    3. 若想增加更多功能（显示知识图谱等），可以借用[Foam项目的成果](https://foambubble.github.io/foam/recommended-extensions)。
4. 按需编辑页面 
    * wiki里有四种内容：home，标题是日期的，files文件夹、还有各种专题（比如资料库.md 复现人工智能应用.md）。日常开发流水账写到日期.md里，如果学到了某主题的知识，就新建一个专题记录。home.md记录当前进度、待办事项、总体规划、账目。
5. 上传