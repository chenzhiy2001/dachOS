* 讲解文本编辑器、make、apt等实用工具的常见用法
    * 安装nyancat
    * 安装gedit